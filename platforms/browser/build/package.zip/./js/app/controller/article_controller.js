//var ArticleController = {
//  get: function () {
//    ArticleModel.fetch(function (articles) {
//      ArticleView.renderList(articles);
//    }, function (error) {
//      console.log('error ; ', error);
//    });
//  }
//};
